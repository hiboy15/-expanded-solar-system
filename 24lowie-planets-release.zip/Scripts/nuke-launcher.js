const nukeLauncher = extendContent(ItemTurret, "nuke-launcher", {
  shootType: new BulletType(0, 0) {{
    splashDamage = 99999;
    splashDamageRadius = 400;
    hitEffect = Fx.shockwave;
    despawnEffect = Fx.massiveExplosion;
    buildingDamageMultiplier = 999;
    pierceCap = 999;
    collides = false;
    killShooter = true;
    status = StatusEffects.melting;
    statusDuration = 600;
  }},

  placed(tile){
    this.super$placed(tile);
    Vars.ui.showInfoPopup("[scarlet]WARNING: IF LAUNCHED IT WILL BE OP[]", 5, Align.center, 0, 0, 0, 0);
  },

  shoot(type){
    Groups.player.each(p => {
      p.con.shake(25, 25);
      p.sendMessage("[scarlet]WARNING: NUKE LAUNCHED[]");
    });
    this.super$shoot(type);
    Time.run(3, () => this.kill());
  }
});

nukeLauncher.ammo(Items.thorium, nukeLauncher.shootType);