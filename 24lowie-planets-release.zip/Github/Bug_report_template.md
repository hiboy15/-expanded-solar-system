---
name: Bug Report
about: Something broke in the planet
title: "[Bug] Brief description"
labels: bug
---

**Type**:
<!-- Crash, Bug, Visual, Balance, Compatibility -->

**Mindustry Version**:
<!-- e.g. v154 Build 144 -->

**Terra Version**:
<!-- e.g. v0.1 -->

**OS**:
<!-- Windows 11 / Android 14 / Linux -->

**Other Mods**:
<!-- None or list them -->

### Description
<!-- What went wrong? Be specific -->


### Expected Behavior
<!-- What should happen instead? -->

### Logs
<!-- Paste Mindustry/logs/client.txt here between the backticks -->