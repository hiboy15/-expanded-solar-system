import mindustry.mod.Mod;
import mindustry.game.EventType.ClientLoadEvent;
import arc.Events;
import mindustry.ui.dialogs.BaseDialog;
import arc.graphics.Color;
import arc.scene.ui.layout.Table;
import arc.scene.ui.Image;
import mindustry.ui.Icons;

public class LowiePlanetsMod extends Mod {

    @Override
    public void init() {
        Events.on(ClientLoadEvent.class, e -> {
            if(Core.settings.getBool("lowie-mail-seen-v01", false)) return; // only show once

            BaseDialog mailUI = new BaseDialog("");

            // Header with envelope icon
            Table header = new Table();
            header.add(new Image(Icons.mail)).size(32f).padRight(8f);
            header.add("[red]DEV MAIL SYSTEM").color(Color.scarlet).row();
            header.add("[gray]24lowie-planets v0.1-beta").fontScale(0.8f);

            mailUI.cont.add(header).padBottom(15f).row();
            mailUI.cont.add(new Image()).height(2f).width(380f).color(Color.darkGray).row();

            // Message content - hidden at start
            Table message = new Table();
            message.add("[accent]The dev has sent a message").row();
            message.add("Please open it.").padTop(5).row();
            message.add("").padTop(10).row();
            message.add("Uhh well its beta stuff so test").row();
            message.add("and sectors do not exist idk why").row();
            message.add("so i deleted them so idk").row();
            message.add("just play this beta").padBottom(10).row();
            message.add("<Mail ID: BETA-001>").color(Color.gray).fontScale(0.7f);

            // Initial state: just "Open" button
            mailUI.cont.add("You have 1 unread message").color(Color.lightGray).row();
            mailUI.cont.add("From: LowieDev@void.net").fontScale(0.8f).color(Color.gray).padBottom(15f).row();

            mailUI.buttons.button("[accent]Open", Icons.ok, () -> {
                mailUI.cont.clear();
                mailUI.cont.add(header).padBottom(15f).row();
                mailUI.cont.add(new Image()).height(2f).width(380f).color(Color.darkGray).row();
                mailUI.cont.add(message).padTop(10f).row();

                // Add Close button after opening
                mailUI.buttons.clear();
                mailUI.buttons.button("[red]Close", Icons.cancel, mailUI::hide).size(200f, 50f);

                Core.settings.put("lowie-mail-seen-v01", true);
            }).size(200f, 50f);

            mailUI.buttons.button("Later", Icons.cancel, mailUI::hide).size(120f, 50f);

            mailUI.show();
        });
    }
}