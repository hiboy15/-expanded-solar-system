type: drill 
name: dr-5-drill
size: 2
drillSpeed: 2
